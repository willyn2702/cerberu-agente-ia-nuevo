import requests
import platform
import uuid
import datetime

SERVER_URL = "https://web-production-8c7c1.up.railway.app"

def get_device_id():
    system = platform.system()
    if system == "Windows":
        return str(uuid.UUID(int=uuid.getnode()))
    return str(uuid.getnode())

def activar_o_verificar():
    device_id = get_device_id()
    try:
        r = requests.post(f"{SERVER_URL}/activar", json={"id": device_id})
        if r.status_code == 200:
            print(r.json()["mensaje"])
        else:
            print("Error al verificar la activación.")
    except Exception as e:
        print("No se pudo conectar al servidor:", e)

if __name__ == "__main__":
    print("Iniciando Cerberu IA...")
    activar_o_verificar()
    print("Aquí continúa la lógica principal de la app del usuario.")
